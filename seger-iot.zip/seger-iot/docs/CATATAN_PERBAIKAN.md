# Catatan Perbaikan SEGER (v1 → v2)

Dokumen ini merangkum apa yang ditemukan di project versi awal, apa yang diperbaiki, dan bagaimana AI diterapkan sesuai ketentuan tugas ("pengolahan data memakai algoritma AI atau algoritma lain").

## 1. Kondisi versi awal (v1)

| Bagian | Kondisi v1 |
|---|---|
| Edge 1 (ESP32/Wokwi) | Baca DHT22 + potensiometer, moving average, publish MQTT |
| Edge 2 (HP/Termux) | Klasifikasi **rule-based** berbasis skor (if/else dengan ambang tetap) |
| AI | **Belum ada.** Rule-based adalah aturan manual, bukan hasil belajar dari data |
| Deteksi dini | Hanya bereaksi setelah nilai melewati ambang, belum benar-benar "dini" |

Kesimpulan: ketentuan "algoritma AI atau algoritma lain" secara minimal terpenuhi oleh rule-based, tetapi untuk judul proyek yang menjanjikan **deteksi dini**, dan agar setara dengan project kelompok lain yang memakai AI, perlu ditambah komponen AI yang nyata.

## 2. Masalah yang ditemukan dan perbaikannya

| # | Temuan | Dampak | Perbaikan |
|---|---|---|---|
| 1 | Buffer bawaan PubSubClient hanya 256 byte, sedangkan pesan status dari HP (dengan hasil AI dan prediksi) sekitar 270 byte | Pesan status dari HP **dibuang diam-diam** oleh ESP32, `[STATUS dari HP]` tidak muncul | `mqtt.setBufferSize(512)` di `edge1/sketch.ino` |
| 2 | Klasifikasi hanya berdasarkan ambang tetap | Tidak "belajar", tidak ada pembuktian akurasi | Ditambah Decision Tree hasil training (lihat bagian 3) |
| 3 | Tidak ada prediksi tren | Belum ada deteksi dini | Ditambah regresi linier pada riwayat CO2 (lihat bagian 3) |
| 4 | `TOPIC_ID` berbeda antar file (`kelompokmu` vs `kelompok2`) | Data tidak sampai ke HP | Disamakan menjadi `kelompok2` di Edge 1 dan Edge 2 |
| 5 | File `libraries.txt` belum ada di GitHub | Wokwi gagal compile `DHTesp.h` / `PubSubClient.h` | Ditambahkan di `edge1/` |
| 6 | Log CSV hanya menyimpan status rule-based | Tidak bisa membandingkan AI vs rule | Log kini menyimpan `status_ai`, `status_rule`, `co2_prediksi`, `peringatan_dini` |
| 7 | README hanya satu baris | Dosen tidak tahu cara menjalankan | README lengkap (cara jalan, arsitektur, hasil AI) |
| 8 | Script edge 2 gagal total kalau model tidak ada | Rentan saat demo | Fallback otomatis ke rule-based jika `seger_model.py` tidak ditemukan |

## 3. Penerapan AI (jawaban untuk "apa yang perlu ditambahkan")

AI dipasang di **Edge 2 (HP)** sebagai data processing ke-2, terdiri dari dua algoritma.

### 3.1 Klasifikasi: Decision Tree (supervised learning)

- **Input:** suhu, kelembapan, CO2.
- **Output:** NYAMAN / MULAI PENGAP / PENGAP.
- **Alur:** `ai/generate_dataset.py` membuat dataset → `ai/train_model.py` melatih Decision Tree di laptop (scikit-learn) → hasilnya diekspor menjadi `edge2/seger_model.py` berupa fungsi Python murni, sehingga di HP **tidak perlu library tambahan** (ringan untuk edge).
- **Hasil uji (data uji 600 baris):**

| Metode | Akurasi |
|---|---|
| Decision Tree (max_depth=4) | **85,2%** |
| Rule-based (pembanding) | 78,3% |

Fitur paling berpengaruh: CO2 (0,867), suhu (0,091), kelembapan (0,042). Grafik ada di `docs/confusion_matrix.png` dan `docs/decision_tree.png`.

### 3.2 Prediksi tren: regresi linier (deteksi dini)

- Memakai 15 data CO2 terakhir (sekitar 30 detik), dihitung kemiringan tren (ppm/detik) dengan metode kuadrat terkecil.
- Memprediksi CO2 60 detik ke depan dan menghitung perkiraan waktu mencapai batas berikutnya (800 dan 1200 ppm).
- Jika kondisi yang **diprediksi** lebih buruk daripada kondisi sekarang, sistem mengirim **PERINGATAN DINI**.

Pada uji simulasi kenaikan CO2 bertahap (500 ke 1000 ppm), peringatan dini muncul saat status masih NYAMAN, sekitar 8 detik lebih awal daripada rule-based yang baru bereaksi saat CO2 mencapai 800 ppm. Angka ini bergantung pada laju kenaikan pada simulasi.

## 4. Keterbatasan (tulis jujur di PPT/video)

1. **Dataset sintetis.** Karena prototype berjalan di simulator Wokwi, belum ada data ruangan nyata berlabel. Label dibuat dari "indeks ketidaknyamanan" (bobot CO2, suhu, kelembapan) ditambah noise. Akurasi 85,2% adalah akurasi terhadap data sintetis tersebut, **bukan** bukti performa di ruangan sungguhan.
2. **Perbandingan dengan rule-based tidak sepenuhnya adil**, karena label sintetis dibuat dengan bobot yang tidak sama persis dengan aturan rule-based. Gunakan sebagai gambaran, bukan klaim mutlak.
3. **CO2 disimulasikan** dengan potensiometer; sensor nyata (MQ-135/SCD40) belum dipakai.
4. Prediksi tren memakai model linier sederhana; cocok untuk kenaikan stabil, kurang akurat untuk perubahan mendadak (misal pintu dibuka).
5. Broker MQTT publik tidak memiliki autentikasi.

## 5. Pengembangan lanjutan (jika ada waktu)

- Kumpulkan data nyata dari `seger_log.csv` lalu beri label manual (survei "terasa pengap atau tidak"), kemudian latih ulang `train_model.py`.
- Tambah LED/buzzer di Wokwi yang menyala saat status PENGAP (memanfaatkan status balik dari HP).
- Ganti broker ke HiveMQ Cloud dengan username/password.
- Bandingkan dengan algoritma lain (Random Forest, k-NN) pada data nyata.

## 6. Daftar file yang berubah

| File | Status |
|---|---|
| `edge1/sketch.ino` | Diubah (buffer MQTT 512, `TOPIC_ID` = kelompok2) |
| `edge1/diagram.json`, `edge1/libraries.txt` | Dipindah ke folder `edge1/` |
| `edge2/seger_edge2.py` | Diubah total (Decision Tree + prediksi tren + fallback) |
| `edge2/seger_model.py` | **Baru** (dibuat otomatis oleh training) |
| `ai/generate_dataset.py`, `ai/train_model.py`, `ai/dataset_seger.csv` | **Baru** |
| `docs/*` | **Baru** (hasil training, grafik, catatan ini) |
